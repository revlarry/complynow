@extends('layouts.app')

@section('content')
<div class="certify">
  <h3> <img src="img/complynow.jpg" alt="logo"> <br>
      The Certification Portal
  </h3>
</div>


@endsection