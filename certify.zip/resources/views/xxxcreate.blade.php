@extends('layouts.app')

@section('content')
<div class="container">
    <h2 id="title-text">Certification Data Form</h2>
    <form method="POST" action="">
        @csrf
        <div class="form-group">
            <label for="fname">First Name</label>
            <input type="text" class="form-control" id="fname" placeholder="Enter Full name">

            <label for="mname">Middle Name</label>
            <input type="text" class="form-control" id="mname" placeholder="Enter Middle name">   

            <label for="lname">Last Name</label>
            <input type="text" class="form-control" id="lname" placeholder="Enter Last name">         
        </div>


        <div class="form-group">
            <label for="company">Company name</label>
            <input type="text" class="form-control" id="company" placeholder="Enter Company name">
        </div>
        

        <div class="form-group">
            <label for="training">Training Followed</label>
            <input type="text" class="form-control" id="training" placeholder="Enter training followed">
        </div>

    
        <button id="submit" type="submit" class="btn btn-primary">Submit</button>
    </form>
</div>
@endsection