<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Certify extends Model
{
    //
}
