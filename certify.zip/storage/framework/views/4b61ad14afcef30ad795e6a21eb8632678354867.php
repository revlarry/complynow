

<?php $__env->startSection('content'); ?>

<?php if($errors->any()): ?>

<div class="alert alert-danger">
    <ul class="list-group">
        <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <li class="list-group-item text-danger">
                <?php echo e($error); ?>

            </li>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </ul>
</div>

<?php endif; ?>

    <form action="<?php echo e(route('fileupload.store')); ?>" method="POST" enctype="multipart/form-data">
    <?php echo csrf_field(); ?>
    
        <label for="filedesc">Enter file description</label>
        <input type="text" name="filedesc" id="filedesc" class="form-group"><br>

        <label for="file">Upload CSV file</label>
        <input type="file" name="file" id="file" class="form-group">

        <input type="submit" name="submit" id="submit" class="form-group btn-primary">
    </form>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\projects\certify\resources\views/uploads/fileupload.blade.php ENDPATH**/ ?>