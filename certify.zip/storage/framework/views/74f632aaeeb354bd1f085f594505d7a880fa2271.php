

<?php $__env->startSection('content'); ?>
<div class="container">
    <div class="form-style">
        <h2 id="title-text">Certification Form</h2>

        <h3 id="subtitle-text">
            <?php echo e(isset($enrolment) ? 'Edit Enrolment Data' : 'Create Enrolment Data'); ?>


        </h3>

        <?php if($errors->any()): ?>

        <div class="alert alert-danger">
            <ul class="list-group">
                <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <li class="list-group-item text-danger">
                        <?php echo e($error); ?>

                    </li>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </ul>
        </div>

        <?php endif; ?>

        <form method="POST" action="<?php echo e(isset($enrolment) ? route('certify.update',$enrolment->id) : route('certify.store')); ?>">
            <?php echo csrf_field(); ?>
            <?php if(isset($enrolment)): ?>
                <?php echo method_field('PUT'); ?>
            <?php endif; ?>
        
        
            <div class="form-group">
                <label for="fname">First Name</label>
                <input type="text" class="form-control" name="fname" id="fname" placeholder="Enter First name" value=" <?php echo e(isset($enrolment) ? $enrolment->fname :''); ?>">

                <label for="mname">Middle Name</label>
                <input type="text" class="form-control" name="mname"  id="mname" placeholder="Enter Middle name" value="<?php echo e(isset($enrolment) ? $enrolment->mname :''); ?>">   

                <label for="lname">Last Name</label>
                <input type="text" class="form-control" name="lname" id="lname" placeholder="Enter Last name" value="<?php echo e(isset($enrolment) ? $enrolment->lname :''); ?>">         
            </div>


            <div class="form-group">
                <label for="company">Company name</label>
                <input type="text" class="form-control" name="company" id="company" placeholder="Enter Company name" value="<?php echo e(isset($enrolment) ? $enrolment->company :''); ?>">
            </div>
            

            <div class="form-group">
                <label for="training">Training Followed</label>
                <input type="text" class="form-control" name="training" id="training" placeholder="Enter training followed" value="<?php echo e(isset($enrolment) ? $enrolment->training :''); ?>">
            </div>

            <table>
                <tr>
                    <td>
                        <div class="form-group">
                            <label for="startdate">Start date</label>
                            
                            <input type="datetime-local" class="form-control" name="startdate" id="startdate" placeholder="Enter Start date" value="<?php echo e(isset($enrolment) ? date('d/m/Y H:i',strtotime($enrolment->startdate)) :''); ?>">
                            <?php if(isset($enrolment)): ?>
                                <p><?php echo e(date('d/m/Y H:i',strtotime($enrolment->startdate))); ?>uur</p>
                            <?php endif; ?>
                        </div>
                    </td>

                    <td>
                        <div class="form-group">
                            <label for="enddate">End date</label>
                            <input type="datetime-local" class="form-control" name="enddate" id="enddate" placeholder="Enter End date" >
                            <?php if(isset($enrolment)): ?>
                                <p><?php echo e(date('d/m/Y H:i',strtotime($enrolment->enddate))); ?>uur</p>
                            <?php endif; ?>
                        </div>
                    </td>
                </tr>
            </table>
        
            <button id="submit" type="submit" class="btn btn-primary"> <?php echo e(isset($enrolment) ? 'Update Certificate data' : 'Add New Certificate data'); ?></button>
        </form>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('scripts'); ?>
    <!-- <script src="https://cdn.jsdelivr.net/npm/flatpickr"></script>
    <script>
        flatpickr('#startdate', {
            enableTime:true
        })
        flatpickr('#enddate', {
            enableTime:true
        })
    </script> -->
<?php $__env->stopSection(); ?>

<?php $__env->startSection('css'); ?>
    <!-- <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/flatpickr/dist/flatpickr.min.css"> -->
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\projects\certify\resources\views/certify/create.blade.php ENDPATH**/ ?>