

<?php $__env->startSection('content'); ?>
<div class="container">
        <a id="upload-btn" href="<?php echo e(route('fileupload.create')); ?>" class="btn btn-primary btn-sm  mb-2">Upload a CSV file</a>
        <div class="card card-default">

            <div class="card card-header center">Listing of CSV File Uploads</div>    
            
            <?php if($uploads->count()==0): ?>
            <p>There are no records to display!</p>
            <?php endif; ?>
            <div class="card card-body">
            <table class="table">
                <thead style="background-color:grey;">
                    <th>File Description</th>
                    <th>File Path</th>
                </thead>
                <tbody>
                    <?php $__currentLoopData = $uploads; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $upload): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr>
                        <td><?php echo e($upload->filedesc); ?></td>
                        <td><?php echo e($upload->path); ?></td>
                    </tr>

                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
             </tbody>
             </table>   
                
            
            </div>
        </div>

</div>
   <?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\projects\certify\resources\views/uploads/index.blade.php ENDPATH**/ ?>