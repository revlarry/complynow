<!DOCTYPE html>
<html>
<head>
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <link rel="stylesheet" href="/css/style.css" type="text/css">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@4.5.3/dist/css/bootstrap.min.css" integrity="sha384-TX8t27EcRE3e/ihU7zmQxVncDAy5uIKz4rEkgIXeMed4M0jlfIDPvg6uqKI2xXr2" crossorigin="anonymous">
    <script src="https://kit.fontawesome.com/ca8ab3ac50.js" crossorigin="anonymous"></script>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">

</head>
<body>
    <div class="container">
        <div class="header">
            <img src="/img/complynow.jpg" width="auto" height="200px" alt="">
        </div>

        <div class="topnav" id="myTopnav">
            <a class="active" href="/"> <img src="/img/complynow.jpg" width="auto" height="30px" alt="logo"> Home</a>      
            <?php if(auth()->guard()->check()): ?>
            <a href="<?php echo e(route('certify.create')); ?>">Create</a>
            <?php else: ?>
              <a href="#" class="disabled-link">Create</a>
            <?php endif; ?>
            <a href="<?php echo e(route('certify.index')); ?>">View/Download</a>
            <?php if(auth()->guard()->check()): ?>
                <a href="<?php echo e(route('fileupload.index')); ?>">Upload</a>
            <?php else: ?>
             <a href="#" class="disabled-link">Upload</a>
            <?php endif; ?>
            <a href="javascript:void(0);" class="icon" onclick="myFunction()">
                <i class="fa fa-bars"></i>
            </a>

             <!-- Right Side Of Navbar -->
        
            <!-- Authentication Links -->
            <?php if(auth()->guard()->guest()): ?>
                <a class="nav-link" href="<?php echo e(route('login')); ?>"><?php echo e(__('Login')); ?></a>

                <?php if(Route::has('register')): ?>                
                    <a class="nav-link" href="<?php echo e(route('register')); ?>"><?php echo e(__('Register')); ?></a>
                <?php endif; ?>
            <?php else: ?>
                <a id="navbarDropdown" class="nav-link dropdown-toggle" href="#" role="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false" v-pre>
                    <?php echo e(Auth::user()->name); ?>

                </a>
            
                <a href="<?php echo e(route('logout')); ?>"
                onclick="event.preventDefault();
                                document.getElementById('logout-form').submit();">
                    <?php echo e(__('Logout')); ?>

                </a>

                <form id="logout-form" action="<?php echo e(route('logout')); ?>" method="POST" class="d-none">
                    <?php echo csrf_field(); ?>
                </form>

            <?php endif; ?>

        </div>

   
        <main>
            <br>

            <?php if(session()->has('success')): ?>
                <div class="alert alert-success">
                    <?php echo e(session()->get('success')); ?>

                </div>
            <?php endif; ?>

            <?php echo $__env->yieldContent('content'); ?>
            <?php echo $__env->yieldContent('scripts'); ?>
        </main>

    <footer>   
        <div class="container">
            
            <div class="col-md-4 col-md-offset-4">
                <div class="copyright">
                    &copy; <?php echo date('Y');?> All Rights Reserved.
                    <div class="credits">
                        Designed by <a href="#">Larry Dorkenoo</a></div>
                    </div>
                </div>
            </div>

        </div>
  </footer>


    <script>
        function myFunction() {
            var x = document.getElementById("myTopnav");
            if (x.className === "topnav") {
                x.className += " responsive";
            } else {
                x.className = "topnav";
            }
        }
    </script>

    <script>
        window.onscroll = function() {myFunction2()};

        var navbar = document.getElementById("myTopnav");
        var sticky = navbar.offsetTop;

        function myFunction2() {
            if (window.pageYOffset >= sticky) {
                navbar.classList.add("sticky")
            } else {
                navbar.classList.remove("sticky");
            }
        }
    </script>

    </div>
    <script src="https://code.jquery.com/jquery-3.5.1.slim.min.js"  crossorigin="anonymous"></script>
    <script src="https://cdn.jsdelivr.net/npm/popper.js@1.16.1/dist/umd/popper.min.js"  crossorigin="anonymous"></script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@4.5.3/dist/js/bootstrap.min.js" crossorigin="anonymous"></script>

     <?php echo $__env->yieldContent('scripts'); ?>
</body>
</html><?php /**PATH C:\xampp\htdocs\projects\certify\resources\views/layouts/app.blade.php ENDPATH**/ ?>