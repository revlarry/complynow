

<?php $__env->startSection('content'); ?>
   <div class="card card-default">
       <div class="card card-header center">Listing of Certificates</div>

       <?php if($enrolments->count()==0): ?>
            <p class="center"> There are no records to display!</p>
       <?php endif; ?>

       <div class="card card-body">
           <table class="table">
               <thead>
                   <th>
                       First name
                   </th>
                   <th>
                       Middle name
                   </th>
                   <th>
                       Last name
                   </th>
                   <th>
                       Company
                   </th>
                   
                   <th>
                       Course
                   </th>

                   <th>
                       Start date
                   </th>

                   <th>
                       End date
                   </th>

                    <th> Change
                        <i class="fas fa-user-edit"></i>
                    </th>
                    <th> Delete
                        <i class="far fa-trash-alt"></i>
                    </th>

                   <th>PDF Download
                         <i class="fas fa-download"></i>
                   </th>

               </thead>
               <tbody>
                    <?php $__currentLoopData = $enrolments; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $enrolment): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr>
                        <td>
                            <?php echo e($enrolment->fname); ?>

                        </td>
                        <td>
                            <?php echo e($enrolment->mname); ?>

                        </td>
                        <td>
                            <?php echo e($enrolment->lname); ?>

                        </td>
                        <td>
                            <?php echo e($enrolment->company); ?>

                        </td>
                        <td>
                            <?php echo e($enrolment->training); ?>

                        </td>
                        <td>
                            <?php echo e($enrolment->startdate); ?>

                        </td>
                        <td>
                            <?php echo e($enrolment->enddate); ?>

                        </td>

                        <?php if(auth()->guard()->check()): ?>
                        <td>
                           <a href="<?php echo e(route('certify.edit',$enrolment->id)); ?>" class="btn btn-primary">Edit</a>
                        </td>
                          
                        <td>
                               <a href="#" onclick="return handleDelete(<?php echo e($enrolment->id); ?>)" class="btn btn-danger">Delete</a>
                        </td>

                        <td>                        
                            <a href="<?php echo e(route('pdf2.show',$enrolment->id)); ?>"><i class="fas fa-download"></i></a>                       
                        </td>
                        <?php else: ?>
                        <td>
                           <a href="<?php echo e(route('certify.edit',$enrolment->id)); ?>" class="btn btn-secondary disabled-link">Edit</a>
                        </td>
                          
                        <td>
                               <a href="#" onclick="return handleDelete(<?php echo e($enrolment->id); ?>)" class="btn btn-secondary disabled-link">Delete</a>
                        </td>

                        <td>                        
                            <a href="<?php echo e(route('pdf2.show',$enrolment->id)); ?>" class="disabled-link"><i class="fas fa-download"></i></a>                       
                        </td>
                        <?php endif; ?>
                    </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </tbody>
           </table>

            <!-- Modal -->
            <div class="modal fade" id="deleteModal" data-backdrop="static" data-keyboard="false" tabindex="-1" aria-labelledby="deleteModalLabel" aria-hidden="true">
                <div class="modal-dialog">
                <form action="" method="POST" id="deleteEnrolmentForm">
                    <?php echo csrf_field(); ?>
                    <?php echo method_field('DELETE'); ?>
                    <div class="modal-content">
                        <div class="modal-header">
                            <h5 class="modal-title" id="staticBackdropLabel">Delete this certificate?</h5>
                            <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                            <span aria-hidden="true">&times;</span>
                            </button>
                        </div>
                        <div class="modal-body">
                           <p class="text text-bold">
                               Confirm delete of <?php echo e($enrolment->fname); ?> <?php echo e($enrolment->lname); ?>

                           </p>
                        </div>
                        <div class="modal-footer">
                            <button type="button" class="btn btn-primary" data-dismiss="modal">No, Go Back</button>
                            <button type="submit" class="btn btn-danger">Yes, Delete!</button>
                        </div>
                    </div>
                </form>
                </div>
            </div>


       </div>
   </div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('scripts'); ?>
    <script>
        function handleDelete(id){
           
          
            var form = document.getElementById('deleteEnrolmentForm')
            form.action = '/certify/' + id

            console.log('deleting ...',form)

            $('#deleteModal').modal('show')
        }
        
    </script>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\projects\certify\resources\views/certify/index.blade.php ENDPATH**/ ?>