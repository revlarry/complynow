

<?php $__env->startSection('content'); ?>
<div class="certify">
  <h3> <img src="img/complynow.jpg" alt="logo"> <br>
      The Certification Portal
  </h3>
</div>


<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\projects\certify\resources\views/index.blade.php ENDPATH**/ ?>