

<?php $__env->startSection('content'); ?>
<div class="container">
    <div class="form-style">
        <h2 id="title-text">CSV File Upload Form</h2>

        <h3 id="subtitle-text">
            <!-- <?php echo e(isset($uploads) ? 'Edit Uploads Data' : 'Create Upload Data'); ?> -->

        </h3>

            <div>
                  <?php if($errors->any()): ?>
                        <?php $__currentLoopData = $errors; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <div class="alert alert-danger">
                              <?php echo e($error); ?>

                        </div>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                  <?php endif; ?>
            </div>        
            
            <form class="upload-form" action="<?php echo e(route('upload.store')); ?>" method="POST" enctype="multipart/form-data">
                  <?php echo csrf_field(); ?>
                
                  <label for="filedesc">File Description:</label>
                  <input type="text" name="filedesc"  id="filedesc" class="form-group"><br>

                  <label for="filedesc">Select a CSV file to upload</label><br>

                  <input type="file" name="file" id="file" class="form-group" > <br>
         
                  <input type="submit" name="submit" id="upload-form-submit" class="btn btn-primary btn-lg">
                  
            </form>
      </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\projects\certify\resources\views/layouts/upload.blade.php ENDPATH**/ ?>